package com.example.smartgreenhouse.ui.MyPlant;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.smartgreenhouse.R;

public class PlantItemActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plant_item);
    }
}
