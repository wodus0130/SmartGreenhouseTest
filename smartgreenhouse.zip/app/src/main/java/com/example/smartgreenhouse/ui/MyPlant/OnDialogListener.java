package com.example.smartgreenhouse.ui.MyPlant;

import android.view.View;
import android.view.ViewGroup;

public interface OnDialogListener {
    void onFinish(int position, MyPlant myPlant);

}
