package com.example.smartgreenhouse.ui.plantInfo;

public class PlantInfoItem {
    private String name = null;
    private String code = null;

    // setters
    public void setName(String name) {
        this.name = name;
    }

    public void setCode(String code) {
        this.code = code;
    }

    // getters
    public String getName() {
        return this.name;
    }

    public String getCode() {
        return this.code;
    }

}