package com.example.smartgreenhouse.ui.MyPlant;

public class MyPlant {
    String plantNickname;
    int img;
    String plantPosition;


    public String getPlantNickname() {
        return plantNickname;
    }

    public void setPlantNickname(String plantNickname) {
        this.plantNickname = plantNickname;
    }

    public int getImage() {
        return img;
    }

    public void setImage(int img) {
        this.img = img;
    }

    public String getPlantPosition() {
        return plantPosition;
    }

    public void setPlantPosition(String plantPosition) {
        this.plantPosition = plantPosition;
    }
}
