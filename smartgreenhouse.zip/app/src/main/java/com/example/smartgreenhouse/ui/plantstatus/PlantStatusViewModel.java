package com.example.smartgreenhouse.ui.plantstatus;

import androidx.lifecycle.ViewModel;

public class PlantStatusViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
