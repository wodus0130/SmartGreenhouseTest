package com.example.smartgreenhouse.ui.camera;

import androidx.lifecycle.ViewModel;

public class CameraViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
